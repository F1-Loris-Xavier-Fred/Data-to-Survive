#!/usr/bin/env python3
"""
Build a clean, current Formula 1 dataset (1950 -> present) from the jolpica-f1 API
(the community-maintained, Ergast-compatible successor).

Outputs tidy CSVs in output/:
  races.csv, results.csv, driver_standings.csv, constructor_standings.csv,
  drivers.csv, constructors.csv, circuits.csv, seasons.csv

Every API page is cached to raw/ so re-runs are free and stay under the rate limit.
"""
import json
import time
import hashlib
from pathlib import Path

import requests
import pandas as pd

ROOT = Path(__file__).resolve().parent
RAW = ROOT / "raw"
OUT = ROOT / "output"
RAW.mkdir(exist_ok=True)
OUT.mkdir(exist_ok=True)

BASE = "https://api.jolpi.ca/ergast/f1"
S = requests.Session()
S.headers.update({"User-Agent": "kaggle-f1-dataset/1.0"})


def get(path, **params):
    params.setdefault("format", "json")
    key = hashlib.md5((path + json.dumps(params, sort_keys=True)).encode()).hexdigest()[:16]
    cf = RAW / f"{key}.json"
    if cf.exists():
        return json.loads(cf.read_text())
    for attempt in range(7):
        r = S.get(f"{BASE}/{path}", params=params, timeout=40)
        if r.status_code == 200:
            cf.write_text(r.text)
            time.sleep(0.32)
            return r.json()
        if r.status_code in (429, 500, 502, 503):
            wait = min(75, 6 * (attempt + 1))
            print(f"  {r.status_code} on {path} -> backoff {wait}s")
            time.sleep(wait)
            continue
        r.raise_for_status()
    raise RuntimeError(f"failed {path} {params}")


def pages(path, **params):
    """Yield each page's MRData dict, paginating with limit=100."""
    limit, offset = 100, 0
    while True:
        d = get(path, limit=limit, offset=offset, **params)["MRData"]
        yield d
        total = int(d["total"])
        offset += limit
        if offset >= total:
            break


def g(d, *keys, default=None):
    for k in keys:
        if not isinstance(d, dict) or k not in d:
            return default
        d = d[k]
    return d


# --------------------------------------------------------------------------- #
def build_races():
    rows = []
    for mr in pages("races/"):
        for r in mr["RaceTable"]["Races"]:
            c = r["Circuit"]
            loc = c.get("Location", {})
            rows.append({
                "season": int(r["season"]), "round": int(r["round"]),
                "race_name": r["raceName"], "date": r.get("date"), "time": r.get("time"),
                "circuit_id": c["circuitId"], "circuit_name": c["circuitName"],
                "locality": loc.get("locality"), "country": loc.get("country"),
                "lat": loc.get("lat"), "long": loc.get("long"), "url": r.get("url"),
            })
    df = pd.DataFrame(rows).sort_values(["season", "round"])
    df.to_csv(OUT / "races.csv", index=False)
    print(f"races: {len(df)}")
    return df


def build_results():
    rows = []
    for mr in pages("results/"):
        for r in mr["RaceTable"]["Races"]:
            for res in r.get("Results", []):
                d = res["Driver"]
                con = res["Constructor"]
                fl = res.get("FastestLap", {})
                tm = res.get("Time", {})
                rows.append({
                    "season": int(r["season"]), "round": int(r["round"]),
                    "race_name": r["raceName"], "date": r.get("date"),
                    "driver_id": d["driverId"], "driver_code": d.get("code"),
                    "driver_number": res.get("number"),
                    "driver_name": f"{d.get('givenName','')} {d.get('familyName','')}".strip(),
                    "driver_nationality": d.get("nationality"), "driver_dob": d.get("dateOfBirth"),
                    "constructor_id": con["constructorId"], "constructor_name": con["name"],
                    "constructor_nationality": con.get("nationality"),
                    "grid": res.get("grid"), "position": res.get("position"),
                    "position_text": res.get("positionText"), "points": res.get("points"),
                    "laps": res.get("laps"), "status": res.get("status"),
                    "time_text": tm.get("time"), "time_millis": tm.get("millis"),
                    "fastest_lap_rank": fl.get("rank"), "fastest_lap": g(fl, "Time", "time"),
                    "fastest_lap_speed": g(fl, "AverageSpeed", "speed"),
                })
    df = pd.DataFrame(rows).sort_values(["season", "round", "position_text"])
    df.to_csv(OUT / "results.csv", index=False)
    print(f"results: {len(df)}")
    return df


def build_standings(seasons):
    drv, con = [], []
    for s in seasons:
        d = get(f"{s}/driverStandings/")["MRData"]["StandingsTable"]["StandingsLists"]
        if d:
            for st in d[0].get("DriverStandings", []):
                dr = st["Driver"]
                cons = st.get("Constructors", [{}])
                drv.append({
                    "season": s, "position": st.get("position"), "points": st.get("points"),
                    "wins": st.get("wins"), "driver_id": dr["driverId"],
                    "driver_name": f"{dr.get('givenName','')} {dr.get('familyName','')}".strip(),
                    "driver_nationality": dr.get("nationality"),
                    "constructor": cons[-1].get("name") if cons else None,
                })
        d = get(f"{s}/constructorStandings/")["MRData"]["StandingsTable"]["StandingsLists"]
        if d:
            for st in d[0].get("ConstructorStandings", []):
                co = st["Constructor"]
                con.append({
                    "season": s, "position": st.get("position"), "points": st.get("points"),
                    "wins": st.get("wins"), "constructor_id": co["constructorId"],
                    "constructor_name": co["name"], "nationality": co.get("nationality"),
                })
    pd.DataFrame(drv).to_csv(OUT / "driver_standings.csv", index=False)
    pd.DataFrame(con).to_csv(OUT / "constructor_standings.csv", index=False)
    print(f"driver_standings: {len(drv)} | constructor_standings: {len(con)}")


def build_ref():
    rows = []
    for mr in pages("drivers/"):
        for d in mr["DriverTable"]["Drivers"]:
            rows.append({"driver_id": d["driverId"], "code": d.get("code"),
                         "number": d.get("permanentNumber"),
                         "given_name": d.get("givenName"), "family_name": d.get("familyName"),
                         "dob": d.get("dateOfBirth"), "nationality": d.get("nationality"),
                         "url": d.get("url")})
    pd.DataFrame(rows).to_csv(OUT / "drivers.csv", index=False)
    print(f"drivers: {len(rows)}")

    rows = []
    for mr in pages("constructors/"):
        for c in mr["ConstructorTable"]["Constructors"]:
            rows.append({"constructor_id": c["constructorId"], "name": c["name"],
                         "nationality": c.get("nationality"), "url": c.get("url")})
    pd.DataFrame(rows).to_csv(OUT / "constructors.csv", index=False)
    print(f"constructors: {len(rows)}")

    rows = []
    for mr in pages("circuits/"):
        for c in mr["CircuitTable"]["Circuits"]:
            loc = c.get("Location", {})
            rows.append({"circuit_id": c["circuitId"], "name": c["circuitName"],
                         "locality": loc.get("locality"), "country": loc.get("country"),
                         "lat": loc.get("lat"), "long": loc.get("long"), "url": c.get("url")})
    pd.DataFrame(rows).to_csv(OUT / "circuits.csv", index=False)
    print(f"circuits: {len(rows)}")


def build_seasons():
    rows = []
    for mr in pages("seasons/"):
        for s in mr["SeasonTable"]["Seasons"]:
            rows.append({"season": int(s["season"]), "url": s.get("url")})
    df = pd.DataFrame(rows).sort_values("season")
    df.to_csv(OUT / "seasons.csv", index=False)
    print(f"seasons: {len(df)}")
    return df["season"].tolist()


def main():
    seasons = build_seasons()
    build_races()
    build_results()
    build_ref()
    build_standings(seasons)
    print("F1 build complete ->", OUT)


if __name__ == "__main__":
    main()
